export default function AdminPanel() {
  return (
    <div className="bg-white shadow p-6 rounded-xl">
      <h1 className="text-2xl font-bold mb-4">Painel Administrativo</h1>
      <p>Gerencie seus produtos aqui (em breve: editar, excluir e adicionar).</p>
    </div>
  );
}
