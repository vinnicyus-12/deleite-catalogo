import ProductCard from './ProductCard';

export default function Catalog() {
  const produtos = [
    {
      title: "Colar Corações Prata",
      price: "R$ 2.350,00",
      code: "DEL003",
      image: "/img/colar-coracoes.png"
    },
    {
      title: "Anel Oval Prata",
      price: "R$ 1.180,00",
      code: "DEL004",
      image: "/img/anel-oval.png"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {produtos.map(p => (
        <ProductCard
          key={p.code}
          title={p.title}
          price={p.price}
          code={p.code}
          image={p.image}
        />
      ))}
    </div>
  );
}
