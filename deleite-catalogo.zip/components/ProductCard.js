import { useRouter } from 'next/router';

export default function ProductCard({ title, price, code, image }) {
  const router = useRouter();
  return (
    <div
      onClick={() => router.push(`/produto/${code}`)}
      className="cursor-pointer rounded-xl shadow-md bg-white p-4 hover:shadow-lg transition"
    >
      <img src={image} alt={title} className="w-full h-48 object-cover rounded-md" />
      <h3 className="font-semibold mt-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{price}</p>
      <p className="text-xs text-gray-400">Ref: {code}</p>
    </div>
  );
}
