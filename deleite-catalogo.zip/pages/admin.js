import Head from 'next/head';
import AdminPanel from '@/components/AdminPanel';

export default function Admin() {
  return (
    <>
      <Head>
        <title>Área Administrativa | Deleite</title>
      </Head>
      <main className="min-h-screen bg-blue-50 bg-[url('/textures/pastel-texture.png')] p-4">
        <AdminPanel />
      </main>
    </>
  );
}
