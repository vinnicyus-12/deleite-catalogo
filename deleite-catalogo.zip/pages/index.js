import Head from 'next/head';
import Catalog from '@/components/Catalog';

export default function Home() {
  return (
    <>
      <Head>
        <title>Deleite | Catálogo de Joias em Prata</title>
      </Head>
      <main className="min-h-screen bg-blue-50 bg-[url('/textures/pastel-texture.png')] p-4">
        <Catalog />
      </main>
    </>
  );
}
